try:
    print "Don't Panic!  Running Geo-Tagged Photos to KML"
    print "By Shuksan Geomatics, Bellingham Washington, USA"
    print "Copyright 2018, Gerry Gabrisch (gerry@shuksangeomatics.com)"
    print "\nPlease wait...."
    
    import sys, traceback, os 
    from PIL import Image
    from PIL.ExifTags import TAGS
    import simplekml
    from easygui import  *
    kml = simplekml.Kml()
    
    def get_exif(fn):
        ret = {}
        i = Image.open(fn)
        try:
            info = i._getexif()
            
            for t, v in info.items():
                try:
                    decoded = TAGS.get(t, t)
                    ret[decoded] = v
                except:
                    pass
            if "GPSInfo" in ret:
                return ret["GPSInfo"]
            else:
                return {}
        except:
            return {}
    
    def process_gps(tags):
        gps = {}
        if (tags != None) and (1 in tags) and (not tags[1] == "\x00"): # 1 and 3 are not present if the coords keys are not present and will be null if no coords
            gps["y"] = dmsdec(tags[2][0][0], tags[2][0][1], tags[2][1][0], tags[2][1][1], tags[2][2][0], tags[2][2][1], tags[1])
            gps["x"] = dmsdec(tags[4][0][0], tags[4][0][1], tags[4][1][0], tags[4][1][1], tags[4][2][0], tags[4][2][1], tags[3])
        return gps
    
    def dmsdec(dn, dd, mn, md, sn, sd, o="N"):
        degree = float(dn)/float(dd)
        minute = float(mn)/float(md)/60
        second = float(sn)/float(sd)/3600
        coord = degree + minute + second
        if(o == "S" or o == "W"):
            coord = coord * -1
        return coord
    
    def get_exif_data(fname):
        """Get embedded EXIF image width, height, and data from image file."""
        ret = {}
        ret2 = {}
        try:
            img = Image.open(fname)
            if hasattr( img, '_getexif' ):
                exifinfo = img._getexif()
                if exifinfo != None:
                    for tag, value in exifinfo.items():
                        
                        decoded = TAGS.get(tag, tag)
                        ret[decoded] = value
        except IOError:
            print 'IOERROR ' + fname

        try:
            return [ret['ImageWidth'], ret['ImageLength'],ret['DateTime']]
        except:
            return [ret['ExifImageWidth'], ret['ExifImageHeight'],ret['DateTimeOriginal']]
        
        
    def get_AltAndAzi(fname):
        import PIL
        img = PIL.Image.open(fname)
        exif_data = img._getexif()
        exif = {PIL.ExifTags.TAGS[k]: v
        for k, v in img._getexif().items()
        if k in PIL.ExifTags.TAGS}
        try:
            alt = int(exif['GPSInfo'][6][0]/exif['GPSInfo'][6][1]*3.28084)
        except:
            alt = "No altitude data for this image."
        try:
            azi =  int(exif['GPSInfo'][17][0]/exif['GPSInfo'][17][1])
        except:
            azi = "No camera azimuth data for this image."
        return(alt, azi)
    
    def fDecantonate(s1, s2):
        '''removes the string s1 from the front of string s2'''
        s1l = len(s1)
        if s1 == s2[:s1l]:
            return s2[s1l:]
        else:
            return "fDecantonate failed! Strings do not match, decantonation not possible." 
    

    
    
    textbox("A Shuksan Geomatics hack, copyright 2018, Shuksan Geomatics (gerry@shuksangeomatics.com)","Create KML file for all geo-tagged images (jpg) in a directory.",\
    "Click OK to create KML/CSV or read below.\n\n\n\
This tool will take a directory of geo-tagged images (including images in any subdirectories) and \
it will create both a KML file and a CSV file in that directory. \
 The output KML file can be opened in Google Earth and each image will \
be referenced by a Google Earth icon (a black and white target).  Each \
icon is labeled with the image name using a user defined text color. \
Clicking on an icon in Google Earth will open a balloon box displaying \
the image, the image path relative to the kml, the image capture date, \
camera azimuth, and GNSS elevation.\n\n\
The csv file can be imported into qGIS or ArcGIS with coordinates in WGS84.\n\n\
USER INPUTS\n\n\
1. A directory of images.\n\
2. A project name (will be used to name the output files).\n\n\
Position accuracy is affected by weather, terrain, atmosphere, satellite availability, \
and electronics.  The positions recorded by this tool are extracted from the positions \
recorded by your device.  Positional accuracy is not guaranteed.  You can improve your \
location accuracy by letting your GNSS run prior to capturing images.  Check your location \
in a mapping app like Google Maps to ensure your GNSS is recording your correct location \
before capturing imagery with your device.\n\n\n\
This software is provided AS-IS, without warranty of any kind, expressed or implied, including \
but not limited to the warranties of merchantability, fitness for a particular purpose and \
noninfringment.  In no event shall the authors or copyright holders be liable of any claim, \
damages, or other liability, whether in an action of contract, tort or otherwise, arising \
from, out of or in connection with the software of the use or other dealings in the software.\
It is a copyright violation to distribute this program without permission of the author.\
Copyright 2015, Gerry Gabrisch.")
    
    ##########   input Parameters  ########################
    inDir = diropenbox("Set to the input directory of geo-tagged images.  This directory will also store the output KML file.")
    projectName = enterbox("Enter a Project Name.  The output KML will be named ProjectName_KML.KML", "Create KML file for all geo-tagged images (jpg) in a directory.","ProjectName")
    
    
    #######################################################
    
    outKML = inDir+"\\"+ projectName + "_kml.kml"
    outCSV = inDir+"\\"+ projectName + "_csv.csv"
    
    #remove any existing csv file from the directory, create a new file, and write the csv header
    if os.path.isfile(outCSV):
        os.remove(outCSV)
    f = open(outCSV,'a')
    f.writelines('x,y,imagename,fullpath,imagedate\n')
    

  
    
    
    for (dirpath, dirnames, filenames) in os.walk(inDir):
        for inFile in filenames:
            if inFile.endswith('.jpg') or inFile.endswith('.JPG'):
                
                if dirpath == inDir:
                    relativePath = inFile
                    fullpath = dirpath + "\\"+ inFile
                else:
                    relativePath = fDecantonate(inDir, dirpath)+"\\"+ inFile
                    relativePath = relativePath[1:]
                    fullpath = dirpath + "\\"+ inFile
                try:
                    aa = get_AltAndAzi(fullpath)
                    exifstuff = get_exif_data(fullpath)
                    theTags = get_exif(fullpath)
                    theCoords = process_gps(theTags)
                    tupleCoords =  (theCoords['x'], theCoords['y'])
                    
                except:
                    print "No geotag information.  Image skipped: ", fullpath
                    
                else:
                    print "Creating point data for: ", fullpath
                    relativePath = relativePath.replace(".JPG", ".jpg")
                    thetext ='<img src="'+ relativePath + '" height="' + str(exifstuff[1]/4) + '" width="' + str(exifstuff[0]/4)+\
                    '" alt="path failed"/>'+ '<br>Project Name: '+ projectName+ \
                    '<br>Image Capture Date & Time: '+exifstuff[2]+\
                    '<br>Camera Azimuth(deg): '+ str(aa[1])+ \
                    '<br>GPS Elevation(ft):' + str(aa[0])+ \
                    '<br>Image Location and File Name:'+ relativePath+\
                    "<br><br>Geotagged Images to KML & CSV  - Created by Gerry Gabrisch (gerry@gabrisch.us) 2015"
                   
                    
                    
                 
                    pnt = kml.newpoint(name= inFile, coords=[tupleCoords])
                    pnt.style.iconstyle.icon.href ="http://maps.google.com/mapfiles/kml/shapes/placemark_circle.png"
                    pnt.style.labelstyle.color = simplekml.Color.red
                    pnt.style.labelstyle.scale = 0
                    
                    pnt.style.balloonstyle.text = thetext
                    pnt.style.balloonstyle.bgcolor = simplekml.Color.white
                    pnt.style.balloonstyle.textcolor = simplekml.Color.black
                    
                    f.writelines(str(theCoords['x'])+","+ str(theCoords['y']) +"," + inFile +"," + fullpath +","+  exifstuff[2]+","+ '\n')
                    
    kml.save(outKML)
    f.close()                

    print "Done Without Errors"
    
except:
    tb = sys.exc_info()[2]
    tbinfo = traceback.format_tb(tb)[0]
    print "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
  

   
